#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Header.h"

FILE* Abrir_Arq(char *nome, char *modo)
{
    FILE *arq_palavras;

    arq_palavras = fopen(nome,modo);
    if(arq_palavras != NULL) // Encontrou o arquivo
    {
        return arq_palavras;
    }
    else
    {
        printf("Nao abriu o arquivo: %s ",nome);
        return NULL;
    }
}

ArvoreBin* Adicionar(ArvoreBin *palavras, Info informacoes)
{
    if(palavras == NULL)
    {
        palavras = (ArvoreBin*) malloc(sizeof(ArvoreBin));
        palavras->Dados=informacoes;
        palavras->dir=NULL;
        palavras->esq=NULL;
    }
    else
    {
      /*arvore n�o vazia, verificar se a palavra a ser adicionada tem codigo ASCII
      maior (seguir a direita), sen�o esquerda... */
        if(strcmp(palavras->Dados.palavra,informacoes.palavra))
            Adicionar(palavras->esq,informacoes);
        else
            Adicionar(palavras->dir,informacoes);
    }
    return palavras;
}

void Limpar(ArvoreBin *arvore)
{
    if(arvore != NULL)
    {
        Limpar(arvore->esq);
        Limpar(arvore->dir);
        free(arvore);
    }
}
