#include <stdio.h>
#define TAM 20

typedef struct{
    char palavra[TAM];
    int score;
}Info;

typedef struct arvore_temp{
    Info Dados;
    struct arvore_temp *esq, *dir;
}ArvoreBin;

FILE* Abrir_Arq(char *nome, char *modo);
ArvoreBin* Adicionar(ArvoreBin *palavras, Info informacoes);
void Limpar (ArvoreBin *arvore);
