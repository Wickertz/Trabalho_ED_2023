#include "Header.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
int main()
{
    FILE *arq_palavras=NULL, *criticas=NULL;
    ArvoreBin *palavras=NULL;
    Info informacoes;

    strcpy(informacoes.palavra,"Bom");
    informacoes.score=1;


    arq_palavras = Abrir_Arq("Palavras.txt","r");
    criticas = Abrir_Arq("Criticas.txt","r");
    if(criticas != NULL)
        if(arq_palavras != NULL)
        {
            printf("SHOW!!");
            // LER UMA PALAVRA E SCORE
            palavras = Adicionar(palavras,informacoes); // IR ADICIONANDO AT� COMPLETAR O DICION�RIO DE SCORE






            Limpar(palavras);
        }
    fclose(arq_palavras);
    fclose(criticas);
    return 0;
}
